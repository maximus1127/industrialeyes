<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Calibration extends Model
{
    //
}
